const express = require('express');
const productController = require('../controllers/productController');

const router = express.Router();

router.get('/products', productController.getAllProducts);
router.get('/products/:id', productController.getProductById);
router.post('/products', productController.addProduct);
router.get('/product-count', productController.getProductCount);
router.get('/top-products', productController.getTopProducts);
router.get('/banners', productController.getBanners);
router.put('/products/like/:id', productController.updateLikeCount);
router.put('/products/view/:id', productController.updateViewCount);

module.exports = router;
