// controllers/ProductController.js
const productModel = require('../models/productModel');

const productController = {
    getAllProducts: (req, res) => {
        productModel.getAllProducts((err, results) => {
            if (err) return res.status(500).json({ message: 'Error fetching products' });
            res.json(results);
        });
    },

    getProductById: (req, res) => {
        const { id } = req.params;
        productModel.getProductById(id, (err, results) => {
            if (err) return res.status(500).json({ message: 'Error fetching product details' });
            if (results.length === 0) return res.status(404).json({ message: 'Product not found' });
            res.json(results[0]);
        });
    },

    addProduct: (req, res) => {
        const { title, cat, description, price, img } = req.body;
        const product = { title, cat, description, price, img };

        productModel.addProduct(product, (err, results) => {
            if (err) return res.status(500).json({ message: 'Error adding product' });
            res.json({ message: 'Product added successfully', productId: results.insertId });
        });
    },

    getProductCount: (req, res) => {
        productModel.getProductCount((err, results) => {
            if (err) return res.status(500).json({ message: 'Error fetching product count' });
            res.json(results);
        });
    },

    getTopProducts: (req, res) => {
        productModel.getTopProducts((err, results) => {
            if (err) return res.status(500).json({ message: 'Error fetching top products' });
            res.json(results);
        });
    },

    getBanners: (req, res) => {
        productModel.getBanners((err, results) => {
            if (err) return res.status(500).json({ message: 'Error fetching banners' });
            res.json(results);
        });
    },

    updateViewCount: (req, res) => {
        const { id } = req.params;
        productModel.updateViewCount(id, (err, result) => {
            if (err) {
                console.error('Error updating view count:', err);
                return res.status(500).json({ message: 'Failed to update view count' });
            }
            res.json({ message: 'View count updated successfully' });
        });
    },


    updateLikeCount: (req, res) => {
        const { id } = req.params;
        productModel.updateLikeCount(id, (err, result) => {
            if (err) {
                console.error('Error updating like count:', err);
                return res.status(500).json({ message: 'Failed to update like count' });
            }
            res.json({ message: 'Like count updated successfully' });
        });
    },

};

module.exports = productController;
