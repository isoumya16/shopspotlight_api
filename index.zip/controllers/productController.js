const ProductModel = require('../models/productModel');

const ProductController = {
    getAllProducts: (req, res) => {
        ProductModel.getAllProducts((err, results) => {
            if (err) return res.status(500).json({ message: 'Error fetching products' });
            res.json(results);
        });
    },

    getProductById: (req, res) => {
        const { id } = req.params;
        ProductModel.getProductById(id, (err, results) => {
            if (err) return res.status(500).json({ message: 'Error fetching product details' });
            if (results.length === 0) return res.status(404).json({ message: 'Product not found' });
            res.json(results[0]);
        });
    },

    addProduct: (req, res) => {
        const { title, cat, description, price, img } = req.body;
        const product = { title, cat, description, price, img };

        ProductModel.addProduct(product, (err, results) => {
            if (err) return res.status(500).json({ message: 'Error adding product' });
            res.json({ message: 'Product added successfully', productId: results.insertId });
        });
    },

    getProductCount: (req, res) => {
        ProductModel.getProductCount((err, results) => {
            if (err) return res.status(500).json({ message: 'Error fetching product count' });
            res.json(results);
        });
    },

    getTopProducts: (req, res) => {
        ProductModel.getTopProducts((err, results) => {
            if (err) return res.status(500).json({ message: 'Error fetching top products' });
            res.json(results);
        });
    },

    getBanners: (req, res) => {
        ProductModel.getBanners((err, results) => {
            if (err) return res.status(500).json({ message: 'Error fetching banners' });
            res.json(results);
        });
    },

    updateViewCount: (req, res) => {
        const { id } = req.params;
        ProductModel.updateViewCount(id, (err, result) => {
            if (err) {
                console.error('Error updating view count:', err);
                return res.status(500).json({ message: 'Failed to update view count' });
            }
            res.json({ message: 'View count updated successfully' });
        });
    },


    updateLikeCount: (req, res) => {
        const { id } = req.params;
        ProductModel.updateLikeCount(id, (err, result) => {
            if (err) {
                console.error('Error updating like count:', err);
                return res.status(500).json({ message: 'Failed to update like count' });
            }
            res.json({ message: 'Like count updated successfully' });
        });
    },

    getLikeCount: (req, res) => {
        const { id } = req.params;
        ProductModel.getLikeCount(id, (err, result) => {
            if (err) {
                console.error('Error fetching like count:', err);
                return res.status(500).json({ message: 'Failed to fetch like count' });
            }
            if (result.length === 0) {
                return res.status(404).json({ message: 'Product not found' });
            }
            res.json({ likes: result[0].like_count || 0 });
        });
    },
    updateProduct: (req, res) => {
        const { id, title, cat, description, price, img } = req.body;
        const product = { title, cat, description, price, img };
        ProductModel.updateProduct(id, product, (err, result) => {
            if (err) {
                console.error('Error updating product:', err);
                return res.status(500).json({ message: 'Error updating product' });
            }
            res.json({ message: 'Product updated successfully' });
        });
    },
};

module.exports = ProductController;
