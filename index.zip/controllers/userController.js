const UserModel = require('../models/userModel');

const UserController = {
    register: (req, res) => {
        const user = req.body;
        UserModel.register(user, (err, result) => {
            if (err) {
                console.error('Error registering user:', err);
                return res.status(500).json({ message: 'Error registering user' });
            }
            res.json({ message: 'User registered successfully' });
        });
    },

    login: (req, res) => {
        const { email, password } = req.body;
        UserModel.login(email, (err, results) => {
            if (err) {
                console.error('Error logging in user:', err);
                return res.status(500).json({ message: 'Error logging in user' });
            }
            if (results.length === 0 || results[0].password !== password) {
                return res.status(401).json({ message: 'Invalid email or password' });
            }
            res.json({ message: 'Login successful', user: results[0] });
        });
    },

    updateUser: (req, res) => {
        const { id, firstname, lastname, mobileno, email, password } = req.body;
        const user = { firstname, lastname, mobileno, email, password };
        UserModel.updateUser(id, user, (err, result) => {
            if (err) {
                console.error('Error updating user:', err);
                return res.status(500).json({ message: 'Error updating user' });
            }
            res.json({ message: 'User updated successfully' });
        });
    },

    userList: (req, res) => {
        UserModel.getAllUsers((err, results) => {
            if (err) {
                console.error('Error fetching user list:', err);
                return res.status(500).json({ message: 'Error fetching user list' });
            }
            // res.json({ users: results });
            res.send(JSON.stringify({'status': 200,'error':'','message':results}))
        });
    },

    deleteUser: (req, res) => {
        const { id } = req.body;
        if (!id) {
            return res.status(400).json({ message: 'User ID is required' });
        }
        UserModel.deleteUser(id, (err, result) => {
            if (err) {
                console.error('Error deleting user:', err);
                return res.status(500).json({ message: 'Error deleting user' });
            }
            if (result.affectedRows === 0) {
                return res.status(404).json({ message: 'User not found' });
            }
            res.json({ message: 'User deleted successfully' });
        });
    },
};

module.exports = UserController;
