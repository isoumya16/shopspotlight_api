const db = require('../config/db');

const UserModel = {
    register: (user, callback) => {
        const query = `INSERT INTO users (firstname, lastname, mobileno, email, password) VALUES (?, ?, ?, ?, ?)`;
        db.query(query, [user.firstname, user.lastname, user.mobileno, user.email, user.password], callback);
    },

    login: (email, callback) => {
        const query = `SELECT * FROM users WHERE email = ?`;
        db.query(query, [email], callback);
    },

    updateUser: (id, user, callback) => {
        const query = `UPDATE users SET firstname = ?, lastname = ?, mobileno = ?, email = ?, password = ? WHERE id = ?`;
        db.query(query, [user.firstname, user.lastname, user.mobileno, user.email, user.password, id], callback);
    },

    getAllUsers: (callback) => {
        const query = `SELECT * FROM users`;
        db.query(query, callback);
    },

    deleteUser: (id, callback) => {
        const query = `DELETE FROM users WHERE id = ?`;
        db.query(query, [id], callback);
    },
};

module.exports = UserModel;
