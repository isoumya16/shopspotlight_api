const db = require('../config/db');

const ProductModel = {
    getAllProducts: (callback) => {
        db.query('SELECT * FROM products', callback);
    },

    getProductById: (id, callback) => {
        db.query('SELECT * FROM products WHERE id = ?', [id], callback);
    },

    addProduct: (product, callback) => {
        const query = `INSERT INTO products (title, cat, description, price, img) VALUES (?, ?, ?, ?, ?)`;
        db.query(query, Object.values(product), callback);
    },

    getProductCount: (callback) => {
        const query = `SELECT cat AS category, COUNT(*) AS count FROM products GROUP BY cat`;
        db.query(query, callback);
    },

    getTopProducts: (callback) => {
        const query = `SELECT * FROM products ORDER BY view_count DESC LIMIT 5`;
        db.query(query, callback);
    },

    getBanners: (callback) => {
        const query = `SELECT * FROM banners`;
        db.query(query, callback);
    },

    updateViewCount: (id, callback) => {
        const query = 'UPDATE products SET view_count = view_count + 1 WHERE id = ?';
        db.query(query, [id], callback);
    },

    updateLikeCount: (id, callback) => {
        const query = `UPDATE products SET like_count = like_count + 1 WHERE id = ?`;
        db.query(query, [id], callback);
    },

    getLikeCount: (id, callback) => {
        const query = 'SELECT like_count FROM products WHERE id = ?';
        db.query(query, [id], callback);
    },
    updateProduct: (id, product, callback) => {
        const query = `UPDATE products SET title = ?, cat = ?, description = ?, price = ?, img = ? WHERE id = ?`;
        db.query(query, [product.title, product.cat, product.description, product.price, product.img, id], callback);
    },
};

module.exports = ProductModel;
