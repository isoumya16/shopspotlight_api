const express = require('express');
const ProductController = require('../controllers/productController');

const router = express.Router();

router.get('/products', ProductController.getAllProducts);
router.get('/products/:id', ProductController.getProductById);
router.post('/addproduct', ProductController.addProduct);
router.get('/product-count', ProductController.getProductCount);
router.get('/top-products', ProductController.getTopProducts);
router.get('/banners', ProductController.getBanners);
router.put('/products/like/:id', ProductController.updateLikeCount);
router.get('/products/likes/:id', ProductController.getLikeCount);
router.put('/products/view/:id', ProductController.updateViewCount);
router.put('/products/updateproduct', ProductController.updateProduct);

module.exports = router;
