const express = require('express');
const UserController = require('../controllers/userController');

const router = express.Router();

router.post('/registration', UserController.register);
router.post('/login', UserController.login);
router.get('/userlist', UserController.userList);
router.delete('/deleteuser', UserController.deleteUser);
router.put('/updateuser', UserController.updateUser);

module.exports = router;
